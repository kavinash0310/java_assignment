# BankStatement Application

This project is a Spring Boot-based application that interacts with a database to fetch and manage bank statements. Initially set up to work with MySQL, it has now been adapted to use **UCanAccess** to connect to MS Access databases.

## Prerequisites

- **Java 17 or higher** (or a compatible version with your setup)
- **Maven** (for dependency management and building the project)
- **UCanAccess JDBC Driver** (for connecting to MS Access)

## Setting Up the Project

### Step 1: Clone the Repository

First, clone the project repository to your local machine:

```bash
git clone https://github.com/kavinash0310/bankstatement.git
cd bankstatement
```

### Step 2: Install Required Dependencies

The project uses Maven to manage dependencies. Ensure you have Maven installed.

Once Maven is installed, run the following command to install the dependencies:
```bash
mvn install
```

### Step 3: Run Application

```bash
mvn spring-boot:run
```
package com.bank.bankstatement.controller;

import com.bank.bankstatement.model.StatementDTO;
import com.bank.bankstatement.service.StatementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
@RestController
@RequestMapping("/api/statements")
public class StatementController {

    @Autowired
    private StatementService statementService;

    private static final Logger logger = LoggerFactory.getLogger(StatementController.class);

    @GetMapping("/{accountId}")
    @PreAuthorize("hasAuthority('ROLE_USER') or hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<?> getStatements(
            @PathVariable Long accountId,
            @RequestParam(required = false) LocalDate fromDate,
            @RequestParam(required = false) LocalDate toDate,
            @RequestParam(required = false) BigDecimal fromAmount,
            @RequestParam(required = false) BigDecimal toAmount,
            Authentication authentication) {
        try {
            String role = authentication.getAuthorities().stream()
                    .findFirst().get().getAuthority();

            if ("ROLE_USER".equals(role)) {
                if (fromDate != null || toDate != null || fromAmount != null || toAmount != null) {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access to filter by date or amount.");
                }

                List<StatementDTO> statements = statementService.fetchLastThreeMonths(accountId);
                return ResponseEntity.ok(statements);
            }

            List<StatementDTO> statements = statementService.fetchStatements(accountId, fromDate, toDate, fromAmount, toAmount);
            return ResponseEntity.ok(statements);

        } catch (IllegalArgumentException ex) {
            logger.error("Invalid argument: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request parameters. " + ex.getMessage());
        } catch (Exception ex) {
            logger.error("Error fetching statements: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred. Please try again later.");
        }
    }
}

package com.bank.bankstatement.service;

import com.bank.bankstatement.entity.Statement;
import com.bank.bankstatement.exception.AccountNotFoundException;
import com.bank.bankstatement.exception.StatementNotFoundException;
import com.bank.bankstatement.model.StatementDTO;
import com.bank.bankstatement.repository.StatementRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatementService {

    private static final Logger logger = LoggerFactory.getLogger(StatementService.class);

    private final StatementRepository statementRepository;

    @Autowired
    public StatementService(StatementRepository statementRepository) {
        this.statementRepository = statementRepository;
    }

    public List<StatementDTO> fetchStatements(Long accountId, LocalDate fromDate, LocalDate toDate, BigDecimal fromAmount, BigDecimal toAmount) {
        try {
            logger.info("Fetching statements for accountId: {}", accountId);

            // Check if there are statements for the account, not using existsById
            List<Statement> statements = statementRepository.findByAccountId(accountId);
            if (statements.isEmpty()) {
                logger.warn("Account with accountId: {} not found or no statements available", accountId);
                throw new AccountNotFoundException("Account not found with ID: " + accountId);
            }

            if (fromDate != null && toDate != null && fromAmount != null && toAmount != null) {
                statements = statementRepository.findByAccountIdAndDatefieldBetweenAndAmountBetween(
                        accountId, fromDate, toDate, fromAmount, toAmount);
            }

            if (statements.isEmpty()) {
                logger.warn("No statements found for accountId: {}", accountId);
                throw new StatementNotFoundException("No statements found for accountId: " + accountId);
            }

            return statements.stream()
                    .map(statement -> {
                        String hashedAccountNumber = hashAccountNumber(statement.getAccount().getId().toString());
                        return new StatementDTO(
                                statement.getId(),
                                statement.getAccount().getId(),
                                hashedAccountNumber,
                                statement.getDatefield(),
                                statement.getAmount()
                        );
                    })
                    .collect(Collectors.toList());
        } catch (AccountNotFoundException e) {
            logger.error("Account not found: {}", e.getMessage());
            throw e;
        } catch (StatementNotFoundException e) {
            logger.error("No statements found: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching statements", e);
            throw new RuntimeException("An error occurred while fetching statements. Please try again later.");
        }
    }


    public List<StatementDTO> fetchLastThreeMonths(Long accountId) {
        LocalDate today = LocalDate.now();
        LocalDate threeMonthsAgo = today.minusMonths(3);

        return fetchStatements(accountId, threeMonthsAgo, today, null, null);
    }

    private String hashAccountNumber(String accountNumber) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(accountNumber.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error hashing account number", e);
            throw new RuntimeException("Error hashing account number", e);
        }
    }
}

package com.bank.bankstatement.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class StatementDTO {
    private Long id;
    private Long accountId;
    private String accountNumber;
    private LocalDate dateField;
    private BigDecimal amount;

    public StatementDTO(Long id, Long accountId, String accountNumber, LocalDate dateField, BigDecimal amount) {
        this.id = id;
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.dateField = dateField;
        this.amount = amount;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public LocalDate getDateField() {
        return dateField;
    }

    public void setDateField(LocalDate dateField) {
        this.dateField = dateField;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}

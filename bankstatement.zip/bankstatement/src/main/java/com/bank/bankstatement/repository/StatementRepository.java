package com.bank.bankstatement.repository;

import com.bank.bankstatement.entity.Statement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface StatementRepository extends CrudRepository<Statement, Long> {

    List<Statement> findByAccountIdAndDatefieldBetweenAndAmountBetween(Long accountId, LocalDate fromDate, LocalDate toDate, BigDecimal fromAmount, BigDecimal toAmount);

    List<Statement> findByAccountId(Long accountId);
}

package com.bank.bankstatement;

import com.bank.bankstatement.controller.StatementController;
import com.bank.bankstatement.model.StatementDTO;
import com.bank.bankstatement.service.StatementService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = StatementController.class)
class StatementControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StatementService statementService;

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void testGetStatements_AdminAccess() throws Exception {
        StatementDTO statement = new StatementDTO(1L, 3L, "hashedAccount", Date.valueOf("2020-05-03").toLocalDate(), new BigDecimal("450.00"));
        List<StatementDTO> statements = Collections.singletonList(statement);

        LocalDate fromDate = LocalDate.of(2020,02,01);
        LocalDate toDate = LocalDate.of(2020,11,30);

        when(statementService.fetchStatements(3L, fromDate, toDate, new BigDecimal("200"), new BigDecimal("700")))
                .thenReturn(statements);

        mockMvc.perform(get("/api/statements/3")
                        .param("fromDate", "2020-02-01")
                        .param("toDate", "2020-11-30")
                        .param("fromAmount", "200")
                        .param("toAmount", "700")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].accountNumber").value("hashedAccount"))
                .andExpect(jsonPath("$[0].amount").value("450.0"));  // Expect BigDecimal amount
    }

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void testGetStatements_InternalServerError() throws Exception {
        LocalDate fromDate = LocalDate.of(2020,01,01);
        LocalDate toDate = LocalDate.of(2020,12,31);

        when(statementService.fetchStatements(3L, fromDate, toDate, new BigDecimal("100"), new BigDecimal("500")))
                .thenThrow(new RuntimeException("Unexpected error"));

        mockMvc.perform(get("/api/statements/3")
                        .param("fromDate", "2020-01-01")
                        .param("toDate", "2020-12-31")
                        .param("fromAmount", "100")
                        .param("toAmount", "500")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("An unexpected error occurred. Please try again later."));
    }

    @Test
    @WithMockUser(username = "user", roles = {"USER"})
    void testGetStatements_UserAccess_ThreeMonths() throws Exception {
        StatementDTO statement = new StatementDTO(1L, 3L, "hashedAccount", Date.valueOf("2020-07-01").toLocalDate(), new BigDecimal("500.00"));
        List<StatementDTO> statements = Collections.singletonList(statement);

        when(statementService.fetchLastThreeMonths(3L)).thenReturn(statements);

        mockMvc.perform(get("/api/statements/3")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].accountNumber").value("hashedAccount"))
                .andExpect(jsonPath("$[0].amount").value("500.0"));
    }

    @Test
    @WithMockUser(username = "user", roles = {"USER"})
    void testGetStatements_UserAccess_UnauthorizedFilters() throws Exception {
        mockMvc.perform(get("/api/statements/3")
                        .param("fromDate", "2021-01-01")
                        .param("toDate", "2021-12-31")
                        .param("fromAmount", "500")
                        .param("toAmount", "1000")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string(containsString("Unauthorized access to filter by date or amount.")));
    }

    @Test
    void testUnauthorizedAccess() throws Exception {
        mockMvc.perform(get("/api/statements/3"))
                .andExpect(status().isUnauthorized());
    }
}

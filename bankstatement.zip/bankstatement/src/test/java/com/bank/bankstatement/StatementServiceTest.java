package com.bank.bankstatement;

import com.bank.bankstatement.entity.Account;
import com.bank.bankstatement.entity.Statement;
import com.bank.bankstatement.exception.AccountNotFoundException;
import com.bank.bankstatement.exception.StatementNotFoundException;
import com.bank.bankstatement.model.StatementDTO;
import com.bank.bankstatement.repository.StatementRepository;
import com.bank.bankstatement.service.StatementService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class StatementServiceTest {

    @Mock
    private StatementRepository statementRepository;

    @InjectMocks
    private StatementService statementService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchStatements_NoFilters() {
        Statement statement = new Statement();
        statement.setId(1L);
        Account account = new Account();
        account.setId(123L);
        statement.setAccount(account);
        statement.setDatefield(LocalDate.of(2020, 1, 1));
        statement.setAmount(new BigDecimal("100.00"));

        when(statementRepository.findByAccountId(123L)).thenReturn(Arrays.asList(statement));

        List<StatementDTO> result = statementService.fetchStatements(123L, null, null, null, null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(LocalDate.of(2020, 1, 1), result.get(0).getDateField());
        assertEquals(new BigDecimal("100.00"), result.get(0).getAmount());
        assertTrue(result.get(0).getAccountNumber().matches("[A-Za-z0-9+/=]+"));
    }

    @Test
    void testFetchStatements_WithFilters() {
        Statement statement = new Statement();
        statement.setId(1L);
        Account account = new Account();
        account.setId(123L);
        statement.setAccount(account);
        statement.setDatefield(LocalDate.of(2020, 1, 1));
        statement.setAmount(new BigDecimal("100.00"));

        when(statementRepository.findByAccountId(123L)).thenReturn(Arrays.asList(statement));

        when(statementRepository.findByAccountIdAndDatefieldBetweenAndAmountBetween(
                123L, LocalDate.of(2020, 1, 1), LocalDate.of(2020, 12, 31), new BigDecimal("50"), new BigDecimal("150")))
                .thenReturn(Arrays.asList(statement));

        List<StatementDTO> result = statementService.fetchStatements(
                123L,
                LocalDate.of(2020, 1, 1),
                LocalDate.of(2020, 12, 31),
                new BigDecimal("50"),
                new BigDecimal("150")
        );

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(LocalDate.of(2020, 1, 1), result.get(0).getDateField());
        assertEquals(new BigDecimal("100.00"), result.get(0).getAmount());
    }



    @Test
    void testFetchStatements_NoStatementsFound() {
        when(statementRepository.findByAccountId(123L)).thenReturn(Collections.emptyList());

        AccountNotFoundException exception = assertThrows(AccountNotFoundException.class, () -> {
            statementService.fetchStatements(123L, null, null, null, null);
        });

        assertEquals("Account not found with ID: 123", exception.getMessage());
    }


    @Test
    void testFetchLastThreeMonths() {
        Statement statement = new Statement();
        statement.setId(1L);
        Account account = new Account();
        account.setId(123L);
        statement.setAccount(account);
        statement.setDatefield(LocalDate.of(2023, 8, 1));
        statement.setAmount(new BigDecimal("100.00"));

        when(statementRepository.findByAccountId(123L)).thenReturn(Arrays.asList(statement));

        List<StatementDTO> result = statementService.fetchLastThreeMonths(123L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(LocalDate.of(2023, 8, 1), result.get(0).getDateField());
        assertEquals(new BigDecimal("100.00"), result.get(0).getAmount());
    }

    @Test
    void testFetchStatements_WithHashing() {
        Statement statement = new Statement();
        statement.setId(1L);
        Account account = new Account();
        account.setId(123L);
        statement.setAccount(account);
        statement.setDatefield(LocalDate.of(2020, 1, 1));
        statement.setAmount(new BigDecimal("100.00"));

        when(statementRepository.findByAccountId(123L)).thenReturn(Arrays.asList(statement));

        List<StatementDTO> result = statementService.fetchStatements(123L, null, null, null, null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.get(0).getAccountNumber().matches("[A-Za-z0-9+/=]+"));
        assertEquals(LocalDate.of(2020, 1, 1), result.get(0).getDateField());
        assertEquals(new BigDecimal("100.00"), result.get(0).getAmount());
    }

    @Test
    void testFetchStatements_WithAccountHash() {
        Statement statement = new Statement();
        statement.setId(1L);
        Account account = new Account();
        account.setId(123L);
        statement.setAccount(account);
        statement.setDatefield(LocalDate.of(2020, 1, 1));
        statement.setAmount(new BigDecimal("100.00"));

        when(statementRepository.findByAccountId(123L)).thenReturn(Arrays.asList(statement));

        List<StatementDTO> result = statementService.fetchStatements(123L, null, null, null, null);

        assertNotNull(result);
        assertTrue(result.get(0).getAccountNumber().matches("[A-Za-z0-9+/=]+"));
    }
}

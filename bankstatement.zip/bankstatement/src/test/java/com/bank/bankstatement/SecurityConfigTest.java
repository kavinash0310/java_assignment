package com.bank.bankstatement;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SecurityConfigTest {

    @Autowired
    private InMemoryUserDetailsManager userDetailsManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private SecurityFilterChain securityFilterChain;

    @Test
    public void testUserDetailsService() {
        UserDetails user = userDetailsManager.loadUserByUsername("user");
        assertNotNull(user);
        assertEquals("user", user.getUsername());
        assertTrue(passwordEncoder.matches("user", user.getPassword()));
    }

    @Test
    public void testPasswordEncoder() {
        assertTrue(passwordEncoder.matches("admin", passwordEncoder.encode("admin")));
    }

    @Test
    public void testSecurityFilterChain() {
        assertNotNull(securityFilterChain);
    }
}

